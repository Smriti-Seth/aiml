import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
path="C:/Users/UEM/OneDrive - University Of Engineering & Management/subject/AI/lab/2024/dataset/random_forest_classifier/"
data=pd.read_csv(path+"Iris_Dataset.csv")
X=data.drop("species",axis=1)
data1=pd.read_csv(path+"Iris_Dataset.csv")
data1.drop(data1.iloc[:,0:4],axis=1, inplace=True)
Y=data1
le = LabelEncoder()
labels = le.fit_transform(Y)
print(Y)
print(labels)
'''path="C:/Users/UEM/OneDrive - University Of Engineering & Management/subject/AI/lab/2024/dataset/decision_tree_regression/"
data=pd.read_csv(path+"diabetes.csv")
X=data.drop("Outcome",axis=1)
data1=pd.read_csv(path+"diabetes.csv")
data1.drop(data1.iloc[:,0:8],axis=1, inplace=True)
Y=data1
print(Y)'''

#X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.4,random_state=15)
X_train,X_test,Y_train,Y_test=train_test_split(X,labels,test_size=0.4,random_state=15)




print(X_train.shape)
print(Y_train.shape)
print(X_test.shape)
print(Y_test.shape)
#log_reg=LogisticRegression(max_iter=10000)
decision_tree=RandomForestRegressor()




decision_tree.fit(X_train, Y_train)
print(decision_tree.get_params())
Y_pred=decision_tree.predict(X_test)
result=0
#confusion_matrix = confusion_matrix(Y_test, Y_pred)
#f1_value=f1_score(Y_test,Y_pred)
mean_sq_error=mean_squared_error(Y_test,Y_pred)
#print("F1 score is: ",f1_value*100)
print("Value of mean square error is: ",mean_sq_error)
#print(confusion_matrix)





